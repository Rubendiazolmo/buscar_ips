use std::io;
use pcap::Device;

/// Tranforma un vector de 4 bytes en un string con formato de IPv4
fn bytes_to_decimal_ip(bytes: &[u8]) -> String {
    if bytes.len() != 4 {
        return String::from("Dirección IP inválida");
    }

    format!("{}.{}.{}.{}", bytes[0], bytes[1], bytes[2], bytes[3])
}

fn main() {
    // list all of the devices pcap tells us are available
    let mut index = 0;
    let interfaces = pcap::Device::list().expect("device lookup failed");
    let num_interfacez = interfaces.len();
    for device in interfaces.clone() {
        println!("{:?}: {:?}", index, device.desc.unwrap());
        index += 1;
    }

    let mut interfaz_selec = String::new();
    io::stdin().read_line(&mut interfaz_selec).expect("No se pudo leer la línea");

    let interfaz_selec_int: Result<usize, _> = interfaz_selec.trim().parse();
    
    // Limpio consola
    clearscreen::clear().expect("failed to clear screen");

    match interfaz_selec_int {
        Ok(indice) => {

            if indice < num_interfacez {
                let interfaz: Device = interfaces[indice].clone();
                println!("Buscando IPs para la interfaz: {:?}", interfaz.clone().desc.unwrap());
                println!("---------------------------------------------------------------");
                // Setup Capture
                let mut cap = pcap::Capture::from_device(interfaz)
                    .unwrap()
                    .immediate_mode(true)
                    .open()
                    .unwrap();

                let mut ips_detectadas: Vec<String> = Vec::new();

                while let Ok(packet) = cap.next_packet() {

                    let packet_data = packet.data;

                    // Acceder al encabezado IP (suponiendo que es IPv4)
                    let ip_header = &packet_data[14..34]; // Suponiendo que los datos de IP comienzan en el byte 14
                        
                    // Asegúrate de que el paquete tiene al menos el tamaño del encabezado IPv4 (20 bytes).
                    if packet_data.len() >= 20 {

                        // Obtengo direcciones IP de la captura.
                        let source_ip = &ip_header[12..16];
                        let destination_ip = &ip_header[16..20];

                        // Paso a formato bonito las IPs.
                        let source_ip_decimal = bytes_to_decimal_ip(source_ip);
                        let _destination_ip_decimal = bytes_to_decimal_ip(destination_ip);
            
                        // Comprobar si la cadena está en el vector
                        if !ips_detectadas.contains(&String::from(source_ip_decimal.clone())) {
                            println!("IP encontrada: {}", source_ip_decimal);
                            println!("---------------------------------------------------------------");
                            ips_detectadas.push(source_ip_decimal)
                        }
                    }
                }
                // get a packet and print its bytes
                println!("{:?}", cap.next_packet());

            } else {
                println!("Índice fuera de los límites. Ingresa un número válido.");
            }
        }
        Err(_) => {
            println!("Entrada no válida. Debes ingresar un número válido.");
        }
    }
}


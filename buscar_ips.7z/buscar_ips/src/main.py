from scapy.all import sniff, IP
import subprocess
import os
os.system("cls")

# Ejecuto wmic nic get NetConnectionID para obtener interfaces y guardo el resultado
interfaces_raw = subprocess.run("wmic nic get NetConnectionID",stdout=subprocess.PIPE)

# Limpio el stdout para obtener los nombres bonitos
interfaces = [interzar.rstrip() for interzar in (interfaces_raw.stdout.decode().splitlines()) if len(interzar.rstrip()) > 0]

for i, interfaz in enumerate(interfaces):
    print(str(i) + ": " + interfaz)

interfaz_seleccionada = int(input("Seleccione la interfaz de red que desea inspecionar: "))

# Nombre de la interfaz de red que deseas monitorear
interface_name = interfaces[interfaz_seleccionada] 

os.system("cls")

print("Capturando paquetes de la interfaz:", interface_name)

# Función para procesar paquetes
def packet_handler(packet):
    if IP in packet:
        source_ip = packet[IP].src
        destination_ip = packet[IP].dst
        print(f"Paquete capturado - IP de origen: {source_ip} - IP de destino: {destination_ip}")

# Captura paquetes en tiempo real en la interfaz especificada
sniff(iface=interface_name, filter="arp", prn=packet_handler)